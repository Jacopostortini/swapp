package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class Article {

    @SerializedName("id")
    private int Id;

    @SerializedName("name")
    private String Name;

    @SerializedName("description")
    private String Description;

    @SerializedName("value")
    private int Price;

    @SerializedName("owner")
    private String Owner;

    @SerializedName("keeper")
    private String Keeper;

    @SerializedName("location")
    private String Location;

    public Article(int id, String name, String description, int price, String owner, String keeper, String location) {
        Id = id;
        Name = name;
        Description = description;
        Price = price;
        Owner = owner;
        Keeper = keeper;
        Location = location;
    }

    public String getLocation() {
        return Location;
    }

    public int getId() {
        return Id;
    }

    public String getName() {
        return Name;
    }

    public String getDescription() {
        return Description;
    }

    public int getPrice() {
        return Price;
    }

    public String getOwner() {
        return Owner;
    }

    public String getKeeper() {
        return Keeper;
    }
}
