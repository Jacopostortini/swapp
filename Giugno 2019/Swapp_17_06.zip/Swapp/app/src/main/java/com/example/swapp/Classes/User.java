package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("username")
    private String Username;

    @SerializedName("mail")
    private String Mail;

    @SerializedName("address")
    private String Address;

    @SerializedName("country_id")
    private Integer CountryId;

    @SerializedName("city")
    private String City;

    @SerializedName("phone_number")
    private String PhoneNumber;

    @SerializedName("zip_code")
    private Integer CAPCode;

    public Integer getCAPCode() {
        return CAPCode;
    }

    public Integer getCountryId() {
        return CountryId;
    }

    public String getUsername() {
        return Username;
    }

    public String getMail() {
        return Mail;
    }

    public String getAddress() {
        return Address;
    }

    public String getCity() {
        return City;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public int howManyAreNull(){
        int counter=0;

        if(Mail==null){
            counter++;
        }
        if(Username==null){
            counter++;
        }
        if(City==null){
            counter++;
        }
        if(Address==null){
            counter++;
        }
        if(PhoneNumber==null){
            counter++;
        }
        if(CAPCode==null){
            counter++;
        }
        return counter;
    }
}
