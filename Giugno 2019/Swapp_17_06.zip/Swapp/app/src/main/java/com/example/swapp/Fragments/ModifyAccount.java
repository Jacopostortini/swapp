package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.User;
import com.example.swapp.R;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class ModifyAccount extends Fragment {

    EditText username;
    TextView mail;
    Spinner country;
    EditText city;
    EditText address;
    EditText phoneNumber;
    EditText cap;


    public ModifyAccount() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setOptionsMenu(R.menu.default_menu);
        return inflater.inflate(R.layout.fragment_modify_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            getAllViews();
            setDetails();
            setSaveButtonOnClick();
            setCountriesSpinnerTexts();
        }
    }

    public void setDetails(){
        ServerService ss=getRetrofitInstance();
        ss.getAllDetails(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){

                    User user=response.body();

                    username.setText(response.body().getUsername());
                    mail.setText(response.body().getMail());

                    if(user.getCountryId()!=null){
                        country.setSelection(user.getCountryId());
                    } else{
                        country.setSelection(0);
                    }

                    if(user.getCity()!=null){
                        city.setText(user.getCity());
                    } else{
                        city.setText(R.string.to_add_information);
                    }

                    if(user.getAddress()!=null){
                        address.setText(user.getAddress());
                    } else{
                        address.setText(R.string.to_add_information);
                    }

                    if(user.getPhoneNumber()!=null){
                        phoneNumber.setText(user.getPhoneNumber());
                    } else{
                        phoneNumber.setText(R.string.to_add_information);
                    }

                    if(user.getCAPCode()!=null){
                        cap.setText(user.getCAPCode()+"");
                    } else{
                        cap.setText(R.string.to_add_information);
                    }
                } else{
                    Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    public void setSaveButtonOnClick(){
        Button button=getView().findViewById(R.id.saveModifyAccount);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=getDetails().get(0);
                String phoneNumber=getDetails().get(2);
                String country=getDetails().get(3);
                String city=getDetails().get(4);
                String address=getDetails().get(5);
                String cap=getDetails().get(6);
                int countryId=0;
                if(country!=null){
                    countryId=Integer.parseInt(country);
                }
                int CAP=0;
                if(cap!=null){
                    CAP=Integer.parseInt(cap);
                }
                ServerService ss=getRetrofitInstance();
                ss.modifyUserDetails(getAccessToken(),
                        username,
                        phoneNumber,
                        countryId,
                        city,
                        address,
                        CAP).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.isSuccessful()){
                            replaceFragment(new Account());
                            setAccountIcon();
                        } else{
                            Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {

                    }
                });
            }
        });
    }

    public ArrayList<String> getDetails(){

        ArrayList<String> arrayList=new ArrayList<>();
        arrayList.add(username.getText().toString());
        arrayList.add(mail.getText().toString());

        if(phoneNumber.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(phoneNumber.getText().toString());
        }
        if(country.getSelectedItemPosition()==0){
            arrayList.add(null);
        } else {
            arrayList.add(country.getSelectedItemPosition()+"");
        }
        if(city.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(city.getText().toString());
        }
        if(address.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(address.getText().toString());
        }
        if(cap.getText().toString().equals(R.string.to_add_information)){
            arrayList.add(null);
        } else{
            arrayList.add(cap.getText().toString());
        }

        return  arrayList;
    }

    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void replaceFragment(Fragment fragment){
        getActivity()
                .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public void getAllViews(){
        username=getView().findViewById(R.id.usernameModifyAccount);
        mail=getView().findViewById(R.id.mailModifyAccount);
        country=getView().findViewById(R.id.countryModifyAccount);
        city=getView().findViewById(R.id.cityModifyAccount);
        address=getView().findViewById(R.id.addressModifyAccount);
        phoneNumber=getView().findViewById(R.id.phoneNumberModifyAccount);
        cap=getView().findViewById(R.id.CAPModifyAccount);

    }

    public void setOptionsMenu(int menu){
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        toolbar.getMenu().clear();
        getActivity().getMenuInflater().inflate(menu, toolbar.getMenu());
    }

    public void setCountriesSpinnerTexts(){
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.country_array, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        country.setAdapter(textes);
    }

    public void setAccountIcon(){
        NavigationView navigationView = getActivity().findViewById(R.id.nav_view);
        final MenuItem item=navigationView.getMenu().findItem(R.id.account);

        ServerService ss=getRetrofitInstance();
        ss.getAllDetails(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    if(response.body().howManyAreNull()!=0){
                        item.setTitle(item.getTitle()+" ("+response.body().howManyAreNull()+")");
                    }
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

}
