package com.example.swapp.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.swapp.Classes.Article;
import com.example.swapp.R;

import java.util.List;

public class ArticlesListViewArrayAdapter extends ArrayAdapter<Article> {

    public ArticlesListViewArrayAdapter(Context context, int resource, List<Article> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater= (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView=inflater.inflate(R.layout.line_article_list, null);

        TextView name=convertView.findViewById(R.id.nameArticleList);
        TextView description=convertView.findViewById(R.id.descriptionArticleList);
        TextView price=convertView.findViewById(R.id.priceArticleList);
        TextView location=convertView.findViewById(R.id.locationArticleList);
        TextView id=convertView.findViewById(R.id.articleIdArticleList);

        Article article=getItem(position);

        id.setText(article.getId()+"");
        name.setText(article.getName());
        description.setText(article.getDescription());
        price.setText(article.getPrice()+"");
        location.setText("To implement");
        return convertView;
    }
}
