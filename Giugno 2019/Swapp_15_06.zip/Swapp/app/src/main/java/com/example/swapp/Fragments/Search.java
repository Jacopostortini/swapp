package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.swapp.Adapters.SearchListViewArrayAdapter;
import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.Article;
import com.example.swapp.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class Search extends Fragment {

    public Search() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            setOnSearchBarChange();
            setSearchSpinnerTexts();
            setMaxDistanceSpinnerTextes();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        SearchView searchView=toolbar.findViewById(R.id.searchBar);
        searchView.setVisibility(View.INVISIBLE);
    }

    public void setSearchSpinnerTexts(){
        Spinner spinner=getView().findViewById(R.id.searchCategorySpinner);
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.search_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(textes);
    }

    public void setMaxDistanceSpinnerTextes(){
        Spinner spinner=getView().findViewById(R.id.maxDistanceSpinner);
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.max_distance_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(textes);
    }

    public void setSearchList(List<Article> list){
        ListView listView=getView().findViewById(R.id.searchList);
        listView.setAdapter(new SearchListViewArrayAdapter(getContext(), R.layout.line_article_list, list));
    }

    public void setOnSearchBarChange(){
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        SearchView searchView=toolbar.findViewById(R.id.searchBar);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                ServerService ss=getRetrofitInstance();
                ss.searchArticlesByHashtag(getAccessToken(), s).enqueue(new Callback<List<Article>>() {
                    @Override
                    public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                        if(response.isSuccessful()){
                            setSearchList(response.body());
                        } else{
                            Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Article>> call, Throwable t) {

                    }
                });
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                ServerService ss=getRetrofitInstance();
                ss.searchArticlesByHashtag(getAccessToken(), s).enqueue(new Callback<List<Article>>() {
                    @Override
                    public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                        if(response.isSuccessful()){
                            setSearchList(response.body());
                        } else{
                            Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Article>> call, Throwable t) {

                    }
                });
                return true;
            }
        });
    }

    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }


}
