package com.example.swapp.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.swapp.Adapters.TagsListViewArrayAdapter;
import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.CustomGridView;
import com.example.swapp.R;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static android.widget.RelativeLayout.BELOW;


public class NewArticle extends Fragment {

    public ArrayList<String> newTagList=new ArrayList<>();

    public NewArticle() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newTagList.add("+");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_new_article, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            getView().findViewById(R.id.mustBeReturnedDate).setVisibility(View.INVISIBLE);
            setRentalPeriodSpinnerTexts();
            createCalendarView();
            saveNewArticle();
            setTagsListView();
            setTagsListViewOnItemClick();
        }
    }
    public void saveNewArticle(){
        Button save=getView().findViewById(R.id.saveNewArticle);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText name=getView().findViewById(R.id.titleNewArticle);
                EditText description=getView().findViewById(R.id.descriptionNewArticle);
                EditText price=getView().findViewById(R.id.priceNewArticle);
                EditText rentalPrice=getView().findViewById(R.id.rentalPriceNewArticle);
                Spinner rentalPeriod=getView().findViewById(R.id.rentalPeriodNewArticle);
                CheckBox mustBeReturned=getView().findViewById(R.id.mustBeReturned);
                long date=0;
                if(mustBeReturned.isChecked()) {
                    CalendarView mustBeReturnedDate = getView().findViewById(R.id.mustBeReturnedDate);
                    date=mustBeReturnedDate.getDate();
                }
                RadioButton shippingPossible=getView().findViewById(R.id.shippingPossibleNewArticle);
                RadioButton shippingNotPossible=getView().findViewById(R.id.shippingNotPossibleNewArticle);
                boolean shipping;
                if(shippingPossible.isChecked()){
                    shipping=true;
                } else if(shippingNotPossible.isChecked()){
                    shipping=false;
                } else{
                    shipping=false;
                }
                boolean borrowable=((CheckBox)getView().findViewById(R.id.isBorrowableNewArticle)).isChecked();
                String tags="";
                for(String s: newTagList){
                    if(newTagList.indexOf(s)!=newTagList.size()-2) {
                        tags += s.replaceFirst("#", "") + ",";
                    } else if (newTagList.indexOf(s)!=newTagList.size()-1){
                        tags += s.replaceFirst("#", "");
                    }
                }
                ServerService ss=getRetrofitInstance();
                ss.createNewArticle(getAccessToken(),
                        name.getText().toString(),
                        description.getText().toString(),
                        Integer.parseInt(price.getText().toString()),
                        tags,
                        mustBeReturned.isChecked(),
                        (int)date,
                        shipping,
                        borrowable,
                        rentalPeriod.getSelectedItemPosition()+1,
                        Integer.parseInt(rentalPrice.getText().toString())).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.isSuccessful()){
                            replaceFragment(new Search());
                            Toast.makeText(getContext(), R.string.article_created, Toast.LENGTH_SHORT).show();
                        } else{
                            Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {

                    }
                });
            }
        });

    }

    public void createCalendarView(){
        CheckBox checkBox=getView().findViewById(R.id.mustBeReturned);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    View calendarView=getView().findViewById(R.id.mustBeReturnedDate);
                    calendarView.setVisibility(View.VISIBLE);
                    View divider=getView().findViewById(R.id.divider2);
                    RelativeLayout.LayoutParams layoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 5);
                    layoutParams.addRule(BELOW, R.id.mustBeReturnedDate);
                    divider.setLayoutParams(layoutParams);
                    getView().findViewById(R.id.mustBeReturnedDateLabel).setVisibility(View.VISIBLE);
                } else{
                    CalendarView calendarView=getView().findViewById(R.id.mustBeReturnedDate);
                    calendarView.setVisibility(View.INVISIBLE);
                    View divider=getView().findViewById(R.id.divider2);
                    RelativeLayout.LayoutParams layoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 5);
                    layoutParams.addRule(BELOW, R.id.mustBeReturned);
                    divider.setLayoutParams(layoutParams);
                    getView().findViewById(R.id.mustBeReturnedDateLabel).setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    public void setTagsListView(){
        CustomGridView gridView=getView().findViewById(R.id.tagNewArticleListView);
        TagsListViewArrayAdapter arrayAdapter=new TagsListViewArrayAdapter(getContext(),
                R.layout.single_tag_cell_layout,
                newTagList);
        gridView.setAdapter(arrayAdapter);
    }

    public void setTagsListViewOnItemClick(){
        CustomGridView gridView=getView().findViewById(R.id.tagNewArticleListView);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(((Button)view.findViewById(R.id.tagButton)).getText().toString().equals("+")){
                    AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
                    builder.setMessage(R.string.new_tag_alert_message);
                    final EditText input = new EditText(getContext());
                    input.setText("#");
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    builder.setView(input);
                    builder.setPositiveButton(R.string.alert_confirm_add, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(!newTagList.contains(input.getText().toString())) {
                                if(input.getText().toString().split("")[1].equals("#")) {
                                    newTagList.add(newTagList.size() - 1, input.getText().toString());
                                } else{
                                    Toast.makeText(getContext(), R.string.tag_must_start_with, Toast.LENGTH_SHORT).show();
                                }
                            }
                            setTagsListView();
                        }
                    });
                    builder.setNegativeButton(R.string.alert_negative_button, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                } else{
                    int i=newTagList.indexOf(((Button)view.findViewById(R.id.tagButton)).getText().toString());
                    newTagList.remove(i);
                    setTagsListView();
                }
            }
        });
    }

    public void setRentalPeriodSpinnerTexts(){
        Spinner spinner=getView().findViewById(R.id.rentalPeriodNewArticle);
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.rental_periods_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(textes);
    }

    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public void replaceFragment(Fragment fragment){
        getActivity()
        .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }
}
