package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.User;
import com.example.swapp.R;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class ModifyAccount extends Fragment {

    public ModifyAccount() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setOptionsMenu(R.menu.default_menu);
        return inflater.inflate(R.layout.fragment_modify_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            setInfos();
            setSaveButtonOnClick();
        }
    }

    public void setInfos(){
        ServerService ss=getRetrofitInstance();
        ss.getAllDetails(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    EditText username=getView().findViewById(R.id.usernameModifyAccount);
                    TextView mail=getView().findViewById(R.id.mailModifyAccount);
                    EditText country=getView().findViewById(R.id.countryModifyAccount);
                    EditText city=getView().findViewById(R.id.cityModifyAccount);
                    EditText address=getView().findViewById(R.id.addressModifyAccount);
                    EditText phoneNumber=getView().findViewById(R.id.phoneNumberModifyAccount);

                    User user=response.body();

                    username.setText(response.body().getUsername());
                    mail.setText(response.body().getMail());

                    if(user.getCountry()!=null){
                        country.setText(user.getCountry());
                    } else{
                        country.setText(R.string.to_add_information);
                    }

                    if(user.getCity()!=null){
                        city.setText(user.getCity());
                    } else{
                        city.setText(R.string.to_add_information);
                    }

                    if(user.getAddress()!=null){
                        address.setText(user.getAddress());
                    } else{
                        address.setText(R.string.to_add_information);
                    }

                    if(user.getPhoneNumber()!=null){
                        phoneNumber.setText(user.getPhoneNumber());
                    } else{
                        phoneNumber.setText(R.string.to_add_information);
                    }
                } else{
                    Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    public void setSaveButtonOnClick(){
        Button button=getView().findViewById(R.id.saveModifyAccount);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=getDetails().get(0);
                String phoneNumber=getDetails().get(2);
                String country=getDetails().get(3);
                String city=getDetails().get(4);
                String address=getDetails().get(5);

                ServerService ss=getRetrofitInstance();
                ss.modifyUserDetails(getAccessToken(),
                        username,
                        phoneNumber,
                        country,
                        city,
                        address).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.isSuccessful()){
                            replaceFragment(new Account());
                        } else{
                            Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {

                    }
                });
            }
        });
    }

    public ArrayList<String> getDetails(){
        EditText username=getView().findViewById(R.id.usernameModifyAccount);
        TextView mail=getView().findViewById(R.id.mailModifyAccount);
        EditText country=getView().findViewById(R.id.countryModifyAccount);
        EditText city=getView().findViewById(R.id.cityModifyAccount);
        EditText address=getView().findViewById(R.id.addressModifyAccount);
        EditText phoneNumber=getView().findViewById(R.id.phoneNumberModifyAccount);

        ArrayList<String> arrayList=new ArrayList<>();
        arrayList.add(username.getText().toString());
        arrayList.add(mail.getText().toString());

        if(phoneNumber.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(phoneNumber.getText().toString());
        }
        if(country.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(country.getText().toString());
        }
        if(city.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(city.getText().toString());
        }
        if(address.getText().toString().equals(getString(R.string.to_add_information))){
            arrayList.add(null);
        } else {
            arrayList.add(address.getText().toString());
        }

        return  arrayList;
    }

    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void replaceFragment(Fragment fragment){
        getActivity()
                .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public void setOptionsMenu(int menu){
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        toolbar.getMenu().clear();
        getActivity().getMenuInflater().inflate(menu, toolbar.getMenu());
    }

}
