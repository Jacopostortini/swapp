package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("username")
    private String Username;

    @SerializedName("mail")
    private String Mail;

    @SerializedName("address")
    private String Address;

    @SerializedName("country")
    private String Country;

    @SerializedName("city")
    private String City;

    @SerializedName("phone_number")
    private String PhoneNumber;

    public User(String username, String mail, String address, String country, String city, String phoneNumber) {
        Username = username;
        Mail = mail;
        Address = address;
        Country = country;
        City = city;
        PhoneNumber = phoneNumber;
    }

    public String getUsername() {
        return Username;
    }

    public String getMail() {
        return Mail;
    }

    public String getAddress() {
        return Address;
    }

    public String getCountry() {
        return Country;
    }

    public String getCity() {
        return City;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public int isSomethingNull(){
        int counter=0;
        if(Mail==null){
            counter++;
        }
        if(Username==null){
            counter++;
        }
        if(Country==null){
            counter++;
        }
        if(City==null){
            counter++;
        }
        if(Address==null){
            counter++;
        }
        if(PhoneNumber==null){
            counter++;
        }
        return counter;
    }
}
