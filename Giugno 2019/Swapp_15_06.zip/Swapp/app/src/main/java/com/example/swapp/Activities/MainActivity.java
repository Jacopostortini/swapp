package com.example.swapp.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.Gravity;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.Token;
import com.example.swapp.Classes.User;
import com.example.swapp.Fragments.Account;
import com.example.swapp.Fragments.ModifyAccount;
import com.example.swapp.Fragments.MyArticles;
import com.example.swapp.Fragments.NewArticle;
import com.example.swapp.Fragments.Search;
import com.example.swapp.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Handler checkTokenHandler=new Handler();
    Runnable checkToken=new Runnable() {
        @Override
        public void run() {
            final SharedPreferences sharedPreferences=getSharedPreferences("Token", MODE_PRIVATE);
            if(sharedPreferences.getString("RefreshToken", null)!=null){
                Toast.makeText(MainActivity.this, "Refresh token request done", Toast.LENGTH_SHORT).show();
                ServerService ss=getRetrofitInstance();
                ss.refreshToken(sharedPreferences.getString("RefreshToken", null)).enqueue(new Callback<Token>() {
                    @Override
                    public void onResponse(Call<Token> call, Response<Token> response) {
                        if(response.isSuccessful()){
                            SharedPreferences.Editor editor=sharedPreferences.edit();
                            editor.putString("AccessToken", response.body().getAccessToken());
                            editor.apply();
                        } else{
                            checkTokenHandler.postDelayed(checkToken, 5000);
                        }
                    }

                    @Override
                    public void onFailure(Call<Token> call, Throwable t) {

                    }
                });
            } else{
                Bundle b=getIntent().getExtras();
                if(b==null){
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    finish();
                } else{
                    if(!b.getBoolean("FromLogin")){
                        startActivity(new Intent(getApplicationContext(), Login.class));
                        finish();
                    }
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //checkToken.run();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, 0, 0);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        addFragment(new Search());
        setVisibleItem(R.id.searchBar);
        setUsernameAndMailInNavigationHeader();
        setAccountIcon();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.default_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        switch (id){
            case R.id.logoutItem:
                getSharedPreferences("Token", MODE_PRIVATE)
                        .edit()
                        .clear()
                        .apply();
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
                break;
            case R.id.modifyAccountItem:
                replaceFragment(new ModifyAccount());
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch(id){
            case R.id.search:
                setVisibleItem(R.id.searchBar);
                replaceFragment(new Search());
                break;
            case R.id.myArticles:
                replaceFragment(new MyArticles());
                break;
            case R.id.borrowedArticles:
                break;
            case R.id.pendingArticles:
                break;
            case R.id.newArticle:
                replaceFragment(new NewArticle());
                break;
            case R.id.newLending:
                break;
            case R.id.recharge:
                break;
            case R.id.rechargeHistory:
                break;
            case R.id.account:
                replaceFragment(new Account());
                break;
            case R.id.settings:
                break;
            case R.id.privacy:
                break;
            default:
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public String getAccessToken(){
        return getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void replaceFragment(Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public void addFragment(Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public void setVisibleItem(int id) {
        Toolbar toolbar=findViewById(R.id.toolbar);
        View item=toolbar.findViewById(id);
        item.setLayoutParams(new Toolbar.LayoutParams(Gravity.END));
        item.setVisibility(View.VISIBLE);
    }

    public void setUsernameAndMailInNavigationHeader(){
        ServerService ss=getRetrofitInstance();
        ss.getUsernameAndMail(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    DrawerLayout drawer = findViewById(R.id.drawer_layout);
                    TextView username=drawer.findViewById(R.id.usernameNavHeader);
                    TextView mail=drawer.findViewById(R.id.mailNavHeader);
                    username.setText(response.body().getUsername());
                    mail.setText(response.body().getMail());
                } else{
                    Toast.makeText(MainActivity.this, "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    public void setAccountIcon(){
        NavigationView navigationView = findViewById(R.id.nav_view);
        final MenuItem item=navigationView.getMenu().findItem(R.id.account);

        ServerService ss=getRetrofitInstance();
        ss.getAllDetails(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){
                    if(response.body().isSomethingNull()!=0){
                        item.setTitle(item.getTitle()+" ("+response.body().isSomethingNull()+")");
                    }
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }


}
