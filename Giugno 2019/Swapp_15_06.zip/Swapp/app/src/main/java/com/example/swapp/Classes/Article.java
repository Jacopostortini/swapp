package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class Article {

    @SerializedName("name")
    private String Name;

    @SerializedName("description")
    private String Description;

    @SerializedName("value")
    private int Price;

    @SerializedName("owner")
    private String Owner;

    @SerializedName("keeper")
    private String Keeper;

    public Article(String name, String description, int price, String owner, String keeper) {
        Name = name;
        Description = description;
        Price = price;
        Owner = owner;
        Keeper = keeper;
    }

    public String getName() {
        return Name;
    }

    public String getDescription() {
        return Description;
    }

    public int getPrice() {
        return Price;
    }

    public String getOwner() {
        return Owner;
    }

    public String getKeeper() {
        return Keeper;
    }
}
