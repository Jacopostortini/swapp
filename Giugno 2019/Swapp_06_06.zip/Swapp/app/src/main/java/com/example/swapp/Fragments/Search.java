package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.swapp.R;

public class Search extends Fragment {

    public Search() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            setSearchSpinnerTexts();
            setMaxDistanceSpinnerTextes();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        SearchView searchView=toolbar.findViewById(R.id.searchBar);
        searchView.setVisibility(View.INVISIBLE);
    }

    public void setSearchSpinnerTexts(){
        Spinner spinner=getView().findViewById(R.id.searchCategorySpinner);
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.search_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(textes);
    }
    public void setMaxDistanceSpinnerTextes(){
        Spinner spinner=getView().findViewById(R.id.maxDistanceSpinner);
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.max_distance_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(textes);
    }


}
