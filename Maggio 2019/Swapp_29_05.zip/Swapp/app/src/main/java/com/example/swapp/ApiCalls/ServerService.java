package com.example.swapp.ApiCalls;

import com.example.swapp.Classes.Token;

import retrofit2.Call;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ServerService {

    String BASE_URL="https://swap-p.herokuapp.com";

    //Login, signUp and token managment

    @POST("/login")
    Call<Token> login(@Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/register")
    Call<Void> signUp(@Query(value = "username") String Username,
                      @Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/refresh_token")
    Call<Token> refreshToken(@Header("authorization") String RefreshToken);
}
