package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("username")
    private String Username;

    @SerializedName("mail")
    private String Mail;

    @SerializedName("address")
    private String Address;

    @SerializedName("country")
    private String Country;

    @SerializedName("city")
    private String City;

    @SerializedName("phone")
    private String PhoneNumber;

    public User(String username, String mail, String address, String country, String city, String phoneNumber) {
        Username = username;
        Mail = mail;
        Address = address;
        Country = country;
        City = city;
        PhoneNumber = phoneNumber;
    }

    public String getUsername() {
        return Username;
    }

    public String getMail() {
        return Mail;
    }

    public String getAddress() {
        return Address;
    }

    public String getCountry() {
        return Country;
    }

    public String getCity() {
        return City;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }
}
