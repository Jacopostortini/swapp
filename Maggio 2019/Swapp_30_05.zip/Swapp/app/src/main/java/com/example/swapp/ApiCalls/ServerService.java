package com.example.swapp.ApiCalls;

import com.example.swapp.Classes.Token;
import com.example.swapp.Classes.User;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ServerService {

    String BASE_URL="https://swap-p.herokuapp.com";

    //Login, signUp and token managment

    @POST("/login")
    Call<Token> login(@Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/register")
    Call<Void> signUp(@Query(value = "username") String Username,
                      @Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/refresh_token")
    Call<Token> refreshToken(@Header("authorization") String RefreshToken);

    //Get user details
    @GET("/user/details/mail_username")
    Call<User> getUsernameAndMail(@Header("authorization") String AccessToken);

    @GET("user/details/all")
    Call<User> getAllDetails(@Header("authorization") String AccessToken);
}
