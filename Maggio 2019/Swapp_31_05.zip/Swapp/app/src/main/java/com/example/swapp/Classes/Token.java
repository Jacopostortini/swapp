package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class Token {
    @SerializedName("access_token")
    private String AccessToken;

    @SerializedName("refresh_token")
    private String RefreshToken;

    public String getAccessToken() {
        return AccessToken;
    }

    public String getRefreshToken() {
        return RefreshToken;
    }
}
