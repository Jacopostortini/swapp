package com.example.swapp.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Toolbar toolbar=findViewById(R.id.signUpToolbar);
        setSupportActionBar(toolbar);
    }

    public void showMainPassword(View view){
        EditText password=findViewById(R.id.mainPassword);
        if(password.getTransformationMethod()!=null){
            password.setTransformationMethod(null);
            ((TextView)findViewById(R.id.showMainPassword)).setText(R.string.hide_password);
        }else{
            password.setTransformationMethod(new PasswordTransformationMethod());
            ((TextView)findViewById(R.id.showMainPassword)).setText(R.string.show_password);
        }
    }
    public void showConfirmPassword(View view){
        EditText password=findViewById(R.id.confirmPassword);
        if(password.getTransformationMethod()!=null){
            password.setTransformationMethod(null);
            ((TextView)findViewById(R.id.showConfirmPassword)).setText(R.string.hide_password);
        }else{
            password.setTransformationMethod(new PasswordTransformationMethod());
            ((TextView)findViewById(R.id.showConfirmPassword)).setText(R.string.show_password);
        }
    }
    public void signUpButton(View view){
        EditText u=findViewById(R.id.usernameSignUp);
        EditText e=findViewById(R.id.emailSignUp);
        EditText mP=findViewById(R.id.mainPassword);
        EditText cP=findViewById(R.id.confirmPassword);
        String username=u.getText().toString();
        final String email=e.getText().toString();
        String mainPassword=mP.getText().toString();
        String confirmPassword=cP.getText().toString();
        if(!username.equals("")&&
                !email.equals("")&&
                !mainPassword.equals("")&&
                !confirmPassword.equals("")) {
            if(mainPassword.equals(confirmPassword)) {
                ServerService ss=getRetrofitInstance();
                ss.signUp(username,
                        email,
                        mainPassword).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.isSuccessful()){
                            Toast.makeText(getApplicationContext(), getString(R.string.confirm_mail_toast), Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(getApplicationContext(), Login.class);
                            i.putExtra("Email", email);
                            startActivity(i);
                            finish();
                        } else if(response.code()==413){
                            Toast.makeText(getApplicationContext(), getString(R.string.mail_already_taken), Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(getApplicationContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {

                    }
                });
            }else{
                Toast.makeText(getApplicationContext(), getString(R.string.passwords_do_not_coincide), Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(getApplicationContext(), getString(R.string.fill_in_all_forms), Toast.LENGTH_SHORT).show();
        }
    }
    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

}
