package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Article {

    @SerializedName("id")
    private int Id;

    @SerializedName("name")
    private String Name;

    @SerializedName("description")
    private String Description;

    @SerializedName("value")
    private int Price;

    @SerializedName("owner")
    private String Owner;

    @SerializedName("keeper")
    private String Keeper;

    @SerializedName("location")
    private String Location;

    @SerializedName("must_be_returned")
    private Boolean MustBeReturned;

    @SerializedName("must_be_returned_date")
    private Integer MustBeReturnedDate;

    @SerializedName("shipping_possible")
    private Boolean ShippingPossible;

    @SerializedName("is_away")
    private Boolean IsAway;

    @SerializedName("hashtags")
    private ArrayList<Hashtag> Hashtags;


    public Boolean getShippingPossible() {
        return ShippingPossible;
    }

    public String getLocation() {
        return Location;
    }

    public int getId() {
        return Id;
    }

    public String getName() {
        return Name;
    }

    public String getDescription() {
        return Description;
    }

    public int getPrice() {
        return Price;
    }

    public String getOwner() {
        return Owner;
    }

    public String getKeeper() {
        return Keeper;
    }

    public Boolean getMustBeReturned() {
        return MustBeReturned;
    }

    public Integer getMustBeReturnedDate() {
        return MustBeReturnedDate;
    }

    public Boolean getAway() {
        return IsAway;
    }

    public ArrayList<String> getHashtags() {
        ArrayList<String> tags = new ArrayList<>();
        for (Hashtag h: Hashtags){
            tags.add(h.getName());
        }
        return tags;
    }
}
