package com.example.swapp.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.example.swapp.R;

import java.util.List;

public class PhotoListArrayAdapter extends ArrayAdapter<Bitmap> {

    private int Resource;

    public PhotoListArrayAdapter(Context context, int resource, List<Bitmap> objects) {
        super(context, resource, objects);
        Resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ViewHolder viewHolder;

        if(convertView==null) {

            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(Resource, null);

            viewHolder = new ViewHolder((ImageView) convertView.findViewById(R.id.singlePhotoLayoutCell));

            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.photo.setImageBitmap(getItem(position));

        return convertView;
    }

    private class ViewHolder{
        private ImageView photo;

        private ViewHolder(ImageView photo) {
            this.photo = photo;
        }
    }
}
