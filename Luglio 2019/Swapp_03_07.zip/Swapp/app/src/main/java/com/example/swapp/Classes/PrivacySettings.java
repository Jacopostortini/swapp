package com.example.swapp.Classes;

public class PrivacySettings {

    private int Id;
    private int Title;
    private int Subtitle;
    private Boolean Checked;

    public PrivacySettings(int id, int title, int subtitle, Boolean checked) {
        Id = id;
        Title = title;
        Subtitle = subtitle;
        Checked = checked;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getTitle() {
        return Title;
    }

    public void setTitle(int title) {
        Title = title;
    }

    public int getSubtitle() {
        return Subtitle;
    }

    public void setSubtitle(int subtitle) {
        Subtitle = subtitle;
    }

    public Boolean getChecked() {
        return Checked;
    }

    public void setChecked(Boolean checked) {
        Checked = checked;
    }
}
