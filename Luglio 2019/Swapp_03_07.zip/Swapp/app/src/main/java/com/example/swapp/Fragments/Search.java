package com.example.swapp.Fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.swapp.Adapters.ArticlesListViewArrayAdapter;
import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.Article;
import com.example.swapp.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class Search extends Fragment {

    Toolbar toolbar;
    SearchView searchView;

    Spinner searchWithParametersSpinner;
    Spinner distanceParametersSpinner;
    ListView searchResultsList;

    Handler setListHandler=new Handler();
    Runnable setListRunnable=new Runnable() {
        @Override
        public void run() {
            setListForEmptyInput();
        }
    };



    public Search() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        toolbar=getActivity().findViewById(R.id.toolbar);
        searchView=toolbar.findViewById(R.id.searchBar);
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            searchView.setLayoutParams(new Toolbar.LayoutParams(Gravity.END));
            searchView.setVisibility(View.VISIBLE);
            toolbar.setTitle(R.string.app_name);
            getAllViews();
            setListForEmptyInput();
            setOnSearchBarChange();
            setSearchSpinnerTexts();
            setMaxDistanceSpinnerTextes();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        searchView.setVisibility(View.INVISIBLE);
    }

    public void setListForEmptyInput(){
        ServerService ss=getRetrofitInstance();
        ss.searchArticlesByName(getAccessToken(), "").enqueue(new Callback<List<Article>>() {
            @Override
            public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                if(response.isSuccessful()){
                    setSearchList(response.body());
                } else {
                    setListHandler.postDelayed(setListRunnable, 1000);
                }
            }

            @Override
            public void onFailure(Call<List<Article>> call, Throwable t) {
                setListHandler.postDelayed(setListRunnable, 1000);
            }
        });
    }

    public void setSearchSpinnerTexts(){
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.search_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        searchWithParametersSpinner.setAdapter(textes);
    }

    public void setMaxDistanceSpinnerTextes(){
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.max_distance_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        distanceParametersSpinner.setAdapter(textes);
    }

    public void setSearchList(List<Article> list){
        searchResultsList.setAdapter(new ArticlesListViewArrayAdapter(getContext(), R.layout.line_article_list, list));
    }

    public void setOnSearchBarChange(){

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                ServerService ss=getRetrofitInstance();
                if(s.length()!=0 && s.split("")[1].equals("#")) {
                    ss.searchArticlesByHashtag(getAccessToken(), s.replaceFirst("#", "")).enqueue(new Callback<List<Article>>() {
                        @Override
                        public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                            if (response.isSuccessful()) {
                                setSearchList(response.body());
                            } else {
                                Toast.makeText(getContext(), "Errore " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Article>> call, Throwable t) {

                        }
                    });
                } else{
                    ss.searchArticlesByName(getAccessToken(), s).enqueue(new Callback<List<Article>>() {
                        @Override
                        public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                            if (response.isSuccessful()) {
                                setSearchList(response.body());
                            } else {
                                Toast.makeText(getContext(), "Errore " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Article>> call, Throwable t) {

                        }
                    });
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                ServerService ss=getRetrofitInstance();
                if(s.length()!=0 && s.split("")[1].equals("#")) {
                    ss.searchArticlesByHashtag(getAccessToken(), s.replaceFirst("#", "")).enqueue(new Callback<List<Article>>() {
                        @Override
                        public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                            if (response.isSuccessful()) {
                                setSearchList(response.body());
                            } else {
                                Toast.makeText(getContext(), "Errore " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Article>> call, Throwable t) {

                        }
                    });
                } else{
                    ss.searchArticlesByName(getAccessToken(), s).enqueue(new Callback<List<Article>>() {
                        @Override
                        public void onResponse(Call<List<Article>> call, Response<List<Article>> response) {
                            if (response.isSuccessful()) {
                                setSearchList(response.body());
                            } else {
                                Toast.makeText(getContext(), "Errore " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Article>> call, Throwable t) {

                        }
                    });
                }
                return true;
            }
        });
    }




    public String getAccessToken(){
        try {
            return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
        } catch (NullPointerException e){
            Log.d("----------", "Null pointer exception in get access token, search fragment");
        }
        return null;
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void getAllViews(){
        searchWithParametersSpinner =getView().findViewById(R.id.searchCategorySpinner);
        distanceParametersSpinner =getView().findViewById(R.id.maxDistanceSpinner);
        searchResultsList =getView().findViewById(R.id.searchList);

    }


}
