package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.User;
import com.example.swapp.R;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class Account extends Fragment {

    private Toolbar toolbar;
    private TextView username;
    private TextView mail;
    private TextView country;
    private TextView city;
    private TextView address;
    private TextView phoneNumber;
    private TextView cap;
    private TextView advice;

    public Account() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        toolbar=getActivity().findViewById(R.id.toolbar);
        setOptionsMenu(R.menu.account_option_menu);
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            getAllViews();
            toolbar.setTitle(R.string.account_action_bar_title);
            advice.setVisibility(View.INVISIBLE);
            setAccountDetails();
        }
    }

    public void getAllViews(){
        username=getView().findViewById(R.id.usernameAccount);
        mail=getView().findViewById(R.id.mailAccount);
        country=getView().findViewById(R.id.countryAccount);
        city=getView().findViewById(R.id.cityAccount);
        address=getView().findViewById(R.id.addressAccount);
        phoneNumber=getView().findViewById(R.id.phoneNumberAccount);
        cap=getView().findViewById(R.id.CAPAccount);
        advice=getView().findViewById(R.id.adviceToComplete);
    }

    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void setAccountDetails(){
        ServerService ss=getRetrofitInstance();
        ss.getAllDetails(getAccessToken()).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(response.isSuccessful()){

                    ArrayList<String> countries=new ArrayList<>();
                    countries.addAll(Arrays.asList(getResources().getStringArray(R.array.country_array)));
                    User user=response.body();

                    username.setText(response.body().getUsername());
                    mail.setText(response.body().getMail());

                    if(user.getCountryId()!=null){
                        country.setText(countries.get(user.getCountryId()));
                    } else{
                        country.setText(R.string.to_add_information);
                    }

                    if(user.getCity()!=null){
                        city.setText(user.getCity());
                    } else{
                        city.setText(R.string.to_add_information);
                    }

                    if(user.getAddress()!=null){
                        address.setText(user.getAddress());
                    } else{
                        address.setText(R.string.to_add_information);
                    }

                    if(user.getPhoneNumber()!=null){
                        phoneNumber.setText(user.getPhoneNumber());
                    } else{
                        phoneNumber.setText(R.string.to_add_information);
                    }

                    if(user.getCAPCode()!=null){
                        cap.setText(user.getCAPCode()+"");
                    } else{
                        cap.setText(R.string.to_add_information);
                    }

                    if(user.howManyAreNull()!=0){
                        advice.setVisibility(View.VISIBLE);
                    }
                } else{
                    Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    public void setOptionsMenu(int menu){
        toolbar.getMenu().clear();
        getActivity().getMenuInflater().inflate(menu, toolbar.getMenu());
    }


}
