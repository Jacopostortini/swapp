package com.example.swapp.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.Token;
import com.example.swapp.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Login extends AppCompatActivity {

    String Mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar=findViewById(R.id.loginToolbar);
        setSupportActionBar(toolbar);
        try {
            Mail = getIntent().getExtras().getString("Email");
            setMail();
        }catch (NullPointerException e){
            Log.d("---------", "Null pointer exception in login activity on create");
        }
    }
    public void setMail(){
        EditText editText=findViewById(R.id.emailLogin);
        editText.setText(Mail);
    }

    public void signUpOnClick(View view){
        startActivity(new Intent(getApplicationContext(), SignUp.class));
    }

    public void loginOnClick(View view){
        EditText email=findViewById(R.id.emailLogin);
        EditText password=findViewById(R.id.passwordLogin);
        ServerService ss=getRetrofitInstance();
        ss.login(email.getText().toString(), password.getText().toString()).enqueue(new Callback<Token>() {
            @Override
            public void onResponse(Call<Token> call, Response<Token> response) {
                if(response.isSuccessful()){
                    CheckBox save=findViewById(R.id.saveLogin);
                    SharedPreferences.Editor editor=getSharedPreferences("Token", MODE_PRIVATE).edit();
                    editor.putString("AccessToken", "Bearer "+response.body().getAccessToken());
                    if(save.isChecked()){
                        editor.putString("RefreshToken", "Bearer "+response.body().getRefreshToken());
                    }
                    editor.apply();
                    Intent intent=new Intent(getApplicationContext(), MainActivity.class);
                    intent.putExtra("FromLogin", true);
                    startActivity(intent);
                    finish();
                } else if(response.code()==401){
                    Toast.makeText(Login.this, getString(R.string.wrong_credentials), Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(Login.this, "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Token> call, Throwable t) {

            }
        });
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

}
