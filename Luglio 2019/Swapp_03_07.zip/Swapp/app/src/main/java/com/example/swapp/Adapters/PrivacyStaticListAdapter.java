package com.example.swapp.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.TextView;

import com.example.swapp.Classes.PrivacySettings;
import com.example.swapp.R;

import java.util.List;

public class PrivacyStaticListAdapter extends ArrayAdapter<PrivacySettings> {

    private int Resource;

    public PrivacyStaticListAdapter(Context context, int resource, List<PrivacySettings> objects) {
        super(context, resource, objects);
        Resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView==null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(Resource, null);

            viewHolder = new ViewHolder((TextView) convertView.findViewById(R.id.titlePrivacyStaticList),
                    (TextView)convertView.findViewById(R.id.subtitlePrivacyStaticList),
                    (Switch) convertView.findViewById(R.id.switchPrivacyStaticList));

            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        try {
            viewHolder.title.setText(getItem(position).getTitle());
            viewHolder.subtitle.setText(getItem(position).getSubtitle());
            if(getItem(position).getId()==0){
                viewHolder.switcher.setChecked(getItem(position).getChecked());
            } else{
                viewHolder.switcher.setVisibility(View.INVISIBLE);
            }
        }catch (NullPointerException e){
            Log.d("------------", "Null pointer exception in privacy static list adapter");
        }

        return convertView;
    }

    private class ViewHolder{

        private TextView title;
        private TextView subtitle;
        private Switch switcher;

        private ViewHolder(TextView title, TextView subtitle, Switch switcher) {
            this.title = title;
            this.subtitle = subtitle;
            this.switcher = switcher;
        }
    }
}
