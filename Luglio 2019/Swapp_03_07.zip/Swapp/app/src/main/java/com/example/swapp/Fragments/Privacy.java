package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Switch;

import com.example.swapp.Adapters.PrivacyStaticListAdapter;
import com.example.swapp.Classes.PrivacySettings;
import com.example.swapp.R;

import java.util.ArrayList;


public class Privacy extends Fragment {

    Toolbar toolbar;
    ListView listView;


    public Privacy() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_privacy, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try{
            getAllViews();
            toolbar.setTitle(R.string.privacy_activity_title);
            setListView(false);
            setOnListViewItemClick();
        } catch (NullPointerException e){
            Log.d("------------------", "Null pointer excetion during privacy on create view");
        }
    }

    public void setListView(boolean isChecked){
        //TODO: Getting privacy settings from retrofit
        ArrayList<PrivacySettings> list = new ArrayList<>();

        list.add(new PrivacySettings(0, R.string.location_title, R.string.location_subtitle, isChecked));
        list.add(new PrivacySettings(1, R.string.payments_title, R.string.payments_subtitle, null));

        listView.setAdapter(new PrivacyStaticListAdapter(getContext(), R.layout.line_privacy_static_list, list));
    }

    public void setOnListViewItemClick(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        setListView(!((Switch)view.findViewById(R.id.switchPrivacyStaticList)).isChecked());
                        break;
                    case 1:
                        break;
                    default:
                        break;
                }
            }
        });
    }

    public void getAllViews(){
        toolbar = getActivity().findViewById(R.id.toolbar);
        listView = getView().findViewById(R.id.privacyStaticList);
    }
}
