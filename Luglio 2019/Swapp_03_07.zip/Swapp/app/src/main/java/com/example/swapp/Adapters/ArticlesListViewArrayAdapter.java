package com.example.swapp.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.swapp.Classes.Article;
import com.example.swapp.R;

import java.util.List;

public class ArticlesListViewArrayAdapter extends ArrayAdapter<Article> {

    private int Resource;

    public ArticlesListViewArrayAdapter(Context context, int resource, List<Article> objects) {
        super(context, resource, objects);
        Resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ViewHolder viewHolder;

        if(convertView == null){
            LayoutInflater inflater= (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(Resource, null);

            viewHolder = new ViewHolder((TextView) convertView.findViewById(R.id.nameArticleList),
                    (TextView)convertView.findViewById(R.id.descriptionArticleList),
                    (TextView)convertView.findViewById(R.id.priceArticleList),
                    (TextView)convertView.findViewById(R.id.locationArticleList),
                    (TextView)convertView.findViewById(R.id.articleIdArticleList));

            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        Article article=getItem(position);

        viewHolder.id.setText(article.getId()+"");
        viewHolder.name.setText(article.getName());
        viewHolder.description.setText(article.getDescription());
        viewHolder.price.setText(article.getPrice()+"");
        viewHolder.location.setText("To implement");

        return convertView;
    }

    private class ViewHolder {
        private TextView name;
        private TextView description;
        private TextView price;
        private TextView location;
        private TextView id;

        private ViewHolder(TextView name, TextView description, TextView price, TextView location, TextView id) {
            this.name = name;
            this.description = description;
            this.price = price;
            this.location = location;
            this.id = id;
        }
    }
}
