package com.example.swapp.ApiCalls;

import com.example.swapp.Classes.Article;
import com.example.swapp.Classes.Token;
import com.example.swapp.Classes.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface ServerService {

    String BASE_URL="https://swap-p.herokuapp.com";

    //Login, signUp and token managment

    @POST("/login")
    Call<Token> login(@Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/register")
    Call<Void> signUp(@Query(value = "username") String Username,
                      @Query(value = "mail") String Email,
                      @Query(value = "password") String Password);

    @POST("/refresh_token")
    Call<Token> refreshToken(@Header("authorization") String RefreshToken);

    //Get and modify user details
    @GET("/user/details/mail_username")
    Call<User> getUsernameAndMail(@Header("authorization") String AccessToken);

    @GET("/user/details/all")
    Call<User> getAllDetails(@Header("authorization") String AccessToken);

    @POST("/user/modify")
    Call<Void> modifyUserDetails(@Header("authorization") String AccessToken,
                                 @Query(value = "username") String Username,
                                 @Query(value = "telephone_number") String PhoneNumber,
                                 @Query(value = "country_id") int Country,
                                 @Query(value = "city") String City,
                                 @Query(value = "address") String Address,
                                 @Query(value = "zip_code") int CAPCode);

    //New article and modify article
    @POST("/object/create")
    Call<Void> createNewArticle(@Header("authorization") String AccessToken,
                                @Query(value = "name") String Name,
                                @Query(value = "description") String Description,
                                @Query(value = "object_value") int Price,
                                @Query(value = "hashtags") String Hashtags,
                                @Query(value = "must_be_returned") boolean MustBeReturned,
                                @Query(value = "must_be_returned_date") int MustBeReturnedDate,
                                @Query(value = "shipping_possible") boolean ShippingPossible,
                                @Query(value = "is_borrowable") boolean IsBorrowable,
                                @Query(value = "rental_period_id") int RentalPeriodId,
                                @Query(value = "rental_cost") int RentalCost);

    @PUT("/object/create")
    Call<Void> modifyMyArticle(@Header("authorization") String AccessToken,
                                @Query(value = "name") String Name,
                                @Query(value = "description") String Description,
                                @Query(value = "object_value") int Price,
                                @Query(value = "hashtags") String Hashtags,
                                @Query(value = "must_be_returned") boolean MustBeReturned,
                                @Query(value = "must_be_returned_date") int MustBeReturnedDate,
                                @Query(value = "shipping_possible") boolean ShippingPossible,
                                @Query(value = "is_borrowable") boolean IsBorrowable,
                                @Query(value = "rental_period_id") int RentalPeriodId,
                                @Query(value = "rental_cost") int RentalCost);

    //Search from all
    @GET("/search/name")
    Call<List<Article>> searchArticlesByName(@Header("authorization") String AccessToken,
                                             @Query(value = "name") String Input);

    @GET("/search/hashtag")
    Call<List<Article>> searchArticlesByHashtag(@Header("authorization") String AccessToken,
                                               @Query(value = "hashtag") String Hashtag);

    //My articles
    @GET("/objects/owner/list")
    Call<List<Article>> getMyArticlesList(@Header("authorization") String AccessToken);

    @GET("/object/owner")
    Call<Article> getMyArticleDetails(@Header("authorization") String AccessToken,
                                      @Query(value = "object_id") int Id);
}
