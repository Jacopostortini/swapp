package com.example.swapp.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.Adapters.TagsListViewArrayAdapter;
import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.Article;
import com.example.swapp.Classes.CustomArrayList;
import com.example.swapp.Classes.CustomGridView;
import com.example.swapp.R;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;
import static android.widget.RelativeLayout.BELOW;


public class MyArticleDetails extends Fragment {

    int ID;
    int rentalPeriodId;
    TextView title;
    TextView description;
    CustomGridView tags;
    TextView price;
    TextView rentalPrice;
    TextView rentalPeriod;
    TextView mustBeReturned;
    CalendarView mustBeReturnedDate;
    TextView location;
    CheckBox shippingPossible;
    CheckBox isAway;
    TextView keeperLabel;
    TextView keeper;

    CustomArrayList tagList = new CustomArrayList();

    public MyArticleDetails() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ID=getArguments().getInt("ArticleId");
        setOptionsMenu(R.menu.my_article_menu);
        return inflater.inflate(R.layout.fragment_my_article_details, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            getAllViews();
            mustBeReturnedDate.setVisibility(View.INVISIBLE);
            setDetails();
        }
    }



    public void setDetails(){
        ServerService ss=getRetrofitInstance();
        ss.getMyArticleDetails(getAccessToken(), ID).enqueue(new Callback<Article>() {
            @Override
            public void onResponse(Call<Article> call, Response<Article> response) {
                if(response.isSuccessful()){
                    try {
                        Article article = response.body();
                        title.setText(article.getName());
                        description.setText(article.getDescription());
                        tags.setAdapter(new TagsListViewArrayAdapter(getContext(), R.layout.single_tag_cell_layout, article.getHashtags()));
                        tagList.setList(article.getHashtags());
                        price.setText(article.getPrice() + "");
                        rentalPrice.setText("To implement");
                        rentalPeriod.setText("To implement");
                        rentalPeriodId = 0;
                        if (article.getMustBeReturned() && article.getMustBeReturnedDate()!=null /*TODO: FARE CAMBIARE A RUBBO IMPOSTAZIONI PER CASO NON DEVE ESSERE RESTITUITO*/) {
                            mustBeReturned.setText(R.string.must_be_returned_article_details);
                            mustBeReturnedDate.setVisibility(View.VISIBLE);
                            mustBeReturnedDate.setDate(article.getMustBeReturnedDate());
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                    ViewGroup.LayoutParams.WRAP_CONTENT);
                            layoutParams.addRule(BELOW, R.id.mustBeReturnedDateMyArticleDetails);
                            location.setLayoutParams(layoutParams);
                        } else {
                            mustBeReturned.setText(R.string.hasnt_to_be_returned_article_details);
                        }
                        location.setText(article.getLocation());
                        shippingPossible.setChecked(article.getShippingPossible());
                        isAway.setChecked(article.getAway());
                        if (article.getAway()) {
                            keeper.setText(article.getKeeper());
                        } else {
                            keeperLabel.setTextColor(getResources().getColor(android.R.color.white));
                        }
                    }catch (NullPointerException e){
                        Log.d("----------------", "Null pointer exception in my article details, set details");
                    } catch (NumberFormatException e){
                        Log.d("----------------", "Number format exception in my article details, set details");
                    }
                }else{
                    Toast.makeText(getContext(), "Errore "+response.code()+" "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Article> call, Throwable t) {

            }
        });
    }


    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void setOptionsMenu(int menu){
        Toolbar toolbar=getActivity().findViewById(R.id.toolbar);
        toolbar.getMenu().clear();
        getActivity().getMenuInflater().inflate(menu, toolbar.getMenu());
        toolbar.getMenu().findItem(R.id.modifyMyArticleItem).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                ArrayList<String> list = new ArrayList<>();
                list.add(ID+"");
                list.add(title.getText().toString());
                list.add(description.getText().toString());
                list.add(getStringFromTagsArray());
                list.add(price.getText().toString());
                list.add(rentalPrice.getText().toString());
                list.add(rentalPeriodId+"");
                list.add(mustBeReturned.getText().toString());
                list.add(mustBeReturnedDate.getDate()+"");
                list.add(location.getText().toString());
                list.add(shippingPossible.isChecked()+"");


                ModifyMyArticle modifyMyArticle = new ModifyMyArticle();
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("ArticleDetails", list);
                modifyMyArticle.setArguments(bundle);
                replaceFragment(modifyMyArticle);
                return true;
            }
        });
    }

    public void getAllViews(){
        title = getView().findViewById(R.id.titleMyArticleDetails);
        description = getView().findViewById(R.id.descriptionMyArticleDetails);
        tags = getView().findViewById(R.id.tagsMyArticleDetails);
        price = getView().findViewById(R.id.priceMyArticleDetails);
        rentalPrice = getView().findViewById(R.id.rentalPriceMyArticleDetails);
        rentalPeriod = getView().findViewById(R.id.rentalPeriodMyArticleDetails);
        mustBeReturned = getView().findViewById(R.id.mustBeReturnedMyArticleDetails);
        mustBeReturnedDate = getView().findViewById(R.id.mustBeReturnedDateMyArticleDetails);
        location = getView().findViewById(R.id.locationMyArticleDetails);
        shippingPossible = getView().findViewById(R.id.shippingPossibleMyArticleDetails);
        isAway = getView().findViewById(R.id.isAwayMyArticleDetails);
        keeperLabel = getView().findViewById(R.id.keeperLabelMyArticleDetails);
        keeper = getView().findViewById(R.id.keeperMyArticleDetails);
    }

    public void replaceFragment(Fragment fragment){
        getActivity()
                .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .addToBackStack(null)
                .commit();
    }

    public String getStringFromTagsArray(){
        String s="";
        for(String i: tagList.getList()){
            s+=i.replaceFirst("#", "")+" ";
        }

        s=s.trim();
        s=s.replaceAll(" ", ",");
        return s;
    }


}
