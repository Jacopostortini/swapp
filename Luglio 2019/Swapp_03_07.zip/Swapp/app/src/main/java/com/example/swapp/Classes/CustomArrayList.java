package com.example.swapp.Classes;

import java.util.ArrayList;

public class CustomArrayList {

    private ArrayList<String> List;

    public CustomArrayList() {

    }

    public ArrayList<String> getList() {
        return List;
    }

    public void setList(ArrayList<String> list) {
        List = list;
    }
}
