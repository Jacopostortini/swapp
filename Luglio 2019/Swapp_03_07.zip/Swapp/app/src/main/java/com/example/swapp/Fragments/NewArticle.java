package com.example.swapp.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.swapp.Adapters.PhotoListArrayAdapter;
import com.example.swapp.Adapters.TagsListViewArrayAdapter;
import com.example.swapp.ApiCalls.ServerService;
import com.example.swapp.Classes.CustomGridView;
import com.example.swapp.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import it.sephiroth.android.library.widget.HListView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static android.widget.RelativeLayout.BELOW;


public class NewArticle extends Fragment {

    int IMAGE_GALLERY_REQUEST = 20;

    EditText title;
    EditText description;

    HListView photos;
    ArrayList<Bitmap> photosArrayList=new ArrayList<>();

    CustomGridView tagGridView;
    EditText price;
    EditText rentalPrice;
    Spinner rentalPeriod;
    CheckBox mustBeReturned;
    TextView mustBeReturnedDateLabel;
    CalendarView mustBeReturnedDate;
    View dividerPrice_Location;
    RadioButton shippingPossible;
    RadioButton shippingNotPossible;
    CheckBox isBorrowable;
    Button saveButton;
    Runnable saveRunnable=new Runnable() {
        @Override
        public void run() {
            saveNewArticle();
        }
    };
    Runnable createCalendarRunnable=new Runnable() {
        @Override
        public void run() {
            createCalendarView();
        }
    };
    long dateMillis;

    ArrayList<String> newTagList=new ArrayList<>();

    public NewArticle() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newTagList.add("+");

        photosArrayList.add(((BitmapDrawable)getResources().getDrawable(R.drawable.add_photo_png)).getBitmap());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_new_article, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(getView()!=null){
            ((Toolbar)getActivity().findViewById(R.id.toolbar)).setTitle(R.string.new_article_action_bar_title);
            getAllViews();
            mustBeReturnedDate.setVisibility(View.INVISIBLE);
            saveRunnable.run();
            createCalendarRunnable.run();
            setRentalPeriodSpinnerTexts();
            setTagsListView();
            setTagsListViewOnItemClick();
            setDateMillis();
            setOnPhotoListItemClick();
            photos.setAdapter(new PhotoListArrayAdapter(getContext(), R.layout.single_photo_cell_layout, photosArrayList));
        }
    }
    public void saveNewArticle(){
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            if(!isThereSomethingNull()) {
                long date = 0;
                if (mustBeReturned.isChecked()) {
                    date = dateMillis;
                    Toast.makeText(getContext(), date+"", Toast.LENGTH_LONG).show();
                }
                boolean shipping;
                if (shippingPossible.isChecked()) {
                    shipping = true;
                } else if (shippingNotPossible.isChecked()) {
                    shipping = false;
                } else {
                    shipping = false;
                }
                boolean borrowable = isBorrowable.isChecked();
                String tags = getStringFromTagsArray();
                ServerService ss = getRetrofitInstance();
                ss.createNewArticle(getAccessToken(),
                        title.getText().toString(),
                        description.getText().toString(),
                        Integer.parseInt(price.getText().toString()),
                        tags,
                        mustBeReturned.isChecked(),
                        (int) date,
                        shipping,
                        borrowable,
                        rentalPeriod.getSelectedItemPosition() + 1,
                        Integer.parseInt(rentalPrice.getText().toString())).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {
                            replaceFragment(new MyArticles());
                            Toast.makeText(getContext(), R.string.article_created, Toast.LENGTH_SHORT).show();
                            NavigationView navigationView = getActivity().findViewById(R.id.nav_view);
                            navigationView.setCheckedItem(R.id.myArticles);
                        } else if (response.code() == 444) {
                            Toast.makeText(getContext(), R.string.complete_account_required, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Errore " + response.code() + " " + response.message(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {

                    }
                });
            } else{
                Toast.makeText(getContext(), R.string.fill_in_all_forms, Toast.LENGTH_SHORT).show();
            }
            }
        });

    }

    public void createCalendarView(){
        mustBeReturned.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    mustBeReturnedDate.setVisibility(View.VISIBLE);
                    RelativeLayout.LayoutParams layoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 5);
                    layoutParams.addRule(BELOW, R.id.mustBeReturnedDateNewArticle);
                    dividerPrice_Location.setLayoutParams(layoutParams);
                    mustBeReturnedDateLabel.setVisibility(View.VISIBLE);
                } else{
                    mustBeReturnedDate.setVisibility(View.INVISIBLE);
                    RelativeLayout.LayoutParams layoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 5);
                    layoutParams.addRule(BELOW, R.id.mustBeReturnedNewArticle);
                    dividerPrice_Location.setLayoutParams(layoutParams);
                    mustBeReturnedDateLabel.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    public void setTagsListView(){
        TagsListViewArrayAdapter arrayAdapter=new TagsListViewArrayAdapter(getContext(),
                R.layout.single_tag_cell_layout,
                newTagList);
        tagGridView.setAdapter(arrayAdapter);
    }

    public void setTagsListViewOnItemClick(){
        tagGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(((Button)view.findViewById(R.id.tagButton)).getText().toString().equals("+")){

                    final AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
                    builder.setMessage(R.string.new_tag_alert_message);
                    final EditText input = new EditText(getContext());
                    input.setText("#");
                    input.setSelection(1);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    builder.setView(input);

                    builder.setPositiveButton(R.string.alert_confirm_add, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(!newTagList.contains(input.getText().toString())) {
                                if(input.getText().toString().split("")[1].equals("#")) {
                                    newTagList.add(newTagList.size() - 1, input.getText().toString());
                                } else{
                                    Toast.makeText(getContext(), R.string.tag_must_start_with, Toast.LENGTH_SHORT).show();
                                }
                            }
                            setTagsListView();
                        }
                    });

                    builder.setNegativeButton(R.string.alert_negative_button, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                } else{
                    int i=newTagList.indexOf(((Button)view.findViewById(R.id.tagButton)).getText().toString());
                    newTagList.remove(i);
                    setTagsListView();
                }
            }
        });
    }

    public void setRentalPeriodSpinnerTexts(){
        ArrayAdapter<CharSequence> textes=ArrayAdapter.createFromResource(getContext(), R.array.rental_periods_spinner, android.R.layout.simple_spinner_item);
        textes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rentalPeriod.setAdapter(textes);
    }

    public void setDateMillis(){
        mustBeReturnedDate.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String strDate=(month)+"/"+dayOfMonth+"/"+year;
                try {
                    dateMillis = new SimpleDateFormat("MM/dd/yyyy").parse(strDate).getTime();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void gettingImages(){
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);

        File imgDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String imgDirectoryPath = imgDirectory.getPath();

        Uri data = Uri.parse(imgDirectoryPath);

        photoPickerIntent.setDataAndType(data, "image/*");

        startActivityForResult(photoPickerIntent, IMAGE_GALLERY_REQUEST);
    }

    public void setOnPhotoListItemClick(){
        photos.setOnItemClickListener(new it.sephiroth.android.library.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(it.sephiroth.android.library.widget.AdapterView<?> parent, View view, int position, long id) {
                if(position == photosArrayList.size()-1){
                    gettingImages();
                } else {
                    photosArrayList.remove(position);
                    photos.setAdapter(new PhotoListArrayAdapter(getContext(), R.layout.single_photo_cell_layout, photosArrayList));
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK){
            if(requestCode == IMAGE_GALLERY_REQUEST){
                Uri imgURI= data.getData();

                InputStream inputStream;

                try {
                    inputStream = getActivity().getContentResolver().openInputStream(imgURI);

                    Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);

                    photosArrayList.add(photosArrayList.size()-1, imgBitmap);
                    photos.setAdapter(new PhotoListArrayAdapter(getContext(), R.layout.single_photo_cell_layout, photosArrayList));


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    Toast.makeText(getContext(), R.string.unable_to_open_image, Toast.LENGTH_SHORT).show();
                }
            }
        }
    }



    public String getAccessToken(){
        return getActivity().getSharedPreferences("Token", MODE_PRIVATE).getString("AccessToken", null);
    }

    public void replaceFragment(Fragment fragment){
        getActivity()
        .getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.mainFragmentsLayout, fragment)
                .commit();
    }

    public ServerService getRetrofitInstance(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(ServerService.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ServerService.class);
    }

    public void getAllViews(){
         title = getView().findViewById(R.id.titleNewArticle);
         description = getView().findViewById(R.id.descriptionNewArticle);
         photos = getView().findViewById(R.id.photosNewArticle);
         tagGridView = getView().findViewById(R.id.tagNewArticleListView);
         price = getView().findViewById(R.id.priceNewArticle);
         rentalPrice = getView().findViewById(R.id.rentalPriceNewArticle);
         rentalPeriod = getView().findViewById(R.id.rentalPeriodNewArticle);
         mustBeReturned = getView().findViewById(R.id.mustBeReturnedNewArticle);
         mustBeReturnedDateLabel = getView().findViewById(R.id.mustBeReturnedDateLabelNewArticle);
         mustBeReturnedDate = getView().findViewById(R.id.mustBeReturnedDateNewArticle);
         dividerPrice_Location = getView().findViewById(R.id.divider2);
         shippingPossible = getView().findViewById(R.id.shippingPossibleNewArticle);
         shippingNotPossible = getView().findViewById(R.id.shippingNotPossibleNewArticle);
         isBorrowable = getView().findViewById(R.id.isBorrowableNewArticle);
         saveButton = getView().findViewById(R.id.saveNewArticle);
    }



    public String getStringFromTagsArray(){
        String s="";
        for(String i: newTagList){
            if(newTagList.indexOf(i)==newTagList.size()-1){
                continue;
            }
            s+=i.replaceFirst("#", "")+" ";
        }

        s=s.trim();
        s=s.replaceAll(" ", ",");
        return s;
    }

    public boolean isThereSomethingNull(){
        boolean isNull=false;

        if(title.getText().toString().equals("")){
            title.getBackground().mutate().setColorFilter(getResources().getColor(android.R.color.holo_red_dark), PorterDuff.Mode.SRC_ATOP);
            isNull=true;
        }
        if(description.getText().toString().equals("")){
            description.getBackground().mutate().setColorFilter(getResources().getColor(android.R.color.holo_red_dark), PorterDuff.Mode.SRC_ATOP);
            isNull=true;
        }
        if(price.getText().toString().equals("")){
            price.getBackground().mutate().setColorFilter(getResources().getColor(android.R.color.holo_red_dark), PorterDuff.Mode.SRC_ATOP);
            isNull=true;
        }
        if(rentalPrice.getText().toString().equals("")){
            rentalPrice.getBackground().mutate().setColorFilter(getResources().getColor(android.R.color.holo_red_dark), PorterDuff.Mode.SRC_ATOP);
            isNull=true;
        }
        return isNull;
    }
}