package com.example.swapp.Classes;

import com.google.gson.annotations.SerializedName;

public class Hashtag {

    @SerializedName("hashtag_id")
    private int Id;

    @SerializedName("hashtag_name")
    private String Name;

    @SerializedName("total_times_used")
    private int TotalTimesUsed;

    public int getId() {
        return Id;
    }

    public String getName() {
        return Name;
    }

    public int getTotalTimesUsed() {
        return TotalTimesUsed;
    }
}
